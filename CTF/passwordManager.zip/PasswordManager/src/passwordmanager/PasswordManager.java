package passwordmanager;

import java.util.Scanner;

public class PasswordManager {

    public static void main(String[] args) {
        
        boolean check = true;
        int sel;
        
        PasswordArchive archive = new PasswordArchive();
        
        while (check){
            System.out.println(menu());
            sel = in();
            
            switch(sel){
                case 1:{
                    archive.addPassword(insertPwd());
                    break;
                }
                case 2:{
                    System.out.println(archive.listHashes());
                    break;
                }
                case 3:{
                    check = false;
                    break;
                }
                default:{
                    System.out.println("Wrong, only two options... >:(");
                }
            }
            
        }
        
    }
    
    public static String menu(){
        String result = "PASSWORD MANAGER BY KSUS\n";
        result += "\nThe best password manager available. Once you have inserted your password,\n"
                + "you'll not be able to retrieve them because the only thing that will be saved will be their hashes!\n"
                + "Certified bruh moment!\n\n";
        result += "1- Add password\n2- List passwords\n3- Exit";
        return result;
    }
    
    public static int in(){
        Scanner input = new Scanner(System.in);
        int sel;
        try{
            sel = input.nextInt();
        }catch(Exception e){
            return 0;
        }
        return sel;
    }
    
    public static String insertPwd(){
        Scanner input = new Scanner(System.in);
        System.out.println("Insert your new Password: ");
        String pwd = input.next();
        return pwd;
    }
    
}
